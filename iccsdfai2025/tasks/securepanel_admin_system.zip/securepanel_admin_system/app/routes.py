from flask import render_template, request, redirect, url_for, make_response, flash, jsonify, send_from_directory
from app import app
from app.models import User, Request, Report, Session
import os
import jinja2

@app.route('/')
def index():
    session_id = request.cookies.get('session_web_panel')
    if session_id and Session.get_session(session_id):
        username = Session.get_session(session_id)['username']
        user = User.get_user(username)
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.get_user(username)
        if user and user['password'] == password:
            session_id = Session.create_session(username)
            response = redirect(url_for('dashboard'))
            response.set_cookie('session_web_panel', session_id)
            return response
        error = "Invalid credentials. Please try again."
    
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session_id = request.cookies.get('session_web_panel')
    if session_id:
        Session.delete_session(session_id)
    response = redirect(url_for('login'))
    response.set_cookie('session_web_panel', '', expires=0)
    return response

@app.route('/request', methods=['GET', 'POST'])
def request_form():
    if request.method == 'POST':
        username = request.form.get('username')
        name = request.form.get('name')
        surname = request.form.get('surname')
        password = request.form.get('password')
        description = request.form.get('description')
        
        if User.get_user(username):
            return render_template('request_form.html', error="Username already exists")
        
        request_id = Request.create_request(username, name, surname, password, description)
        return render_template('request_form.html', success=True, request_id=request_id)
    
    return render_template('request_form.html')

@app.route('/dashboard')
def dashboard():
    session_id = request.cookies.get('session_web_panel')
    if not session_id or not Session.get_session(session_id):
        return redirect(url_for('login'))
    
    username = Session.get_session(session_id)['username']
    user = User.get_user(username)
    
    if not user:
        return redirect(url_for('logout'))
    
    return render_template('dashboard.html', user=user)

@app.route('/requests')
def requests_management():
    session_id = request.cookies.get('session_web_panel')
    if not session_id or not Session.get_session(session_id):
        return redirect(url_for('login'))
    
    username = Session.get_session(session_id)['username']
    user = User.get_user(username)
    
    if not user or user['role'] != 'manager':
        return redirect(url_for('dashboard'))
    
    all_requests = Request.get_all_requests()
    return render_template('requests_management.html', requests=all_requests, user=user)

@app.route('/requests/<request_id>')
def request_details(request_id):
    session_id = request.cookies.get('session_web_panel')
    if not session_id or not Session.get_session(session_id):
        return redirect(url_for('login'))
    
    username = Session.get_session(session_id)['username']
    user = User.get_user(username)
    
    if not user or user['role'] != 'manager':
        return redirect(url_for('dashboard'))
    
    req = Request.get_request(request_id)
    if not req:
        return redirect(url_for('requests_management'))
    
    return render_template('request_details.html', req=req, user=user)

@app.route('/approve_request', methods=['POST'])
def approve_request():
    session_id = request.cookies.get('session_web_panel')
    if not session_id or not Session.get_session(session_id):
        return redirect(url_for('login'))
    
    username = Session.get_session(session_id)['username']
    user = User.get_user(username)
    
    if not user or user['role'] != 'manager':
        return redirect(url_for('dashboard'))
    
    request_id = request.form.get('request_id')
    username = request.form.get('username')
    name = request.form.get('name')
    surname = request.form.get('surname')
    password = request.form.get('password')
    role = request.form.get('role', 'user')
    description = request.form.get('description', '')
    
    User.add_user(username, name, surname, password, role, description)
    
    Request.delete_request(request_id)
    
    return redirect(url_for('requests_management'))

@app.route('/users')
def users_list():
    session_id = request.cookies.get('session_web_panel')
    if not session_id or not Session.get_session(session_id):
        return redirect(url_for('login'))
    
    username = Session.get_session(session_id)['username']
    user = User.get_user(username)
    
    if not user or user['role'] != 'admin':
        return redirect(url_for('dashboard'))
    
    all_users = User.get_all_users()
    return render_template('users_list.html', users=all_users, user=user)

@app.route('/report', methods=['GET', 'POST'])
def report_form():
    session_id = request.cookies.get('session_web_panel')
    if not session_id or not Session.get_session(session_id):
        return redirect(url_for('login'))
    
    username = Session.get_session(session_id)['username']
    user = User.get_user(username)
    
    if not user or user['role'] != 'admin':
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        
        report = Report.create_report(title, description)
        blacklist = ['{{', '}}', '=', '"', '\'', '/', '\\', '`', '<', '>', ';', ':', ',', '?', '!', '@', '#', '$', '^', '&', '*']

        if any(char in title for char in blacklist or char in description for char in blacklist):
            return render_template('report_form.html', user=user, error="Invalid characters in input")

        if len(title) > 111:
            return render_template('report_form.html', user=user, error="Title is too long")
        
        template_str = f'Your report "{title}" was sent successfully'
        rendered_notification = jinja2.Template(template_str).render()
        
        return render_template('report_form.html', user=user, notification=rendered_notification)
    
    return render_template('report_form.html', user=user)

@app.route('/robots.txt')
def robots_txt():
    return send_from_directory('static', 'robots.txt')