#!/usr/bin/env python3
import time
import requests
import os
import sys
import chromedriver_autoinstaller

install_dir = os.path.expanduser("~/.chromedriver")
os.makedirs(install_dir, exist_ok=True)
chromedriver_autoinstaller.install(path=install_dir)

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from app.config import BOT_USERNAME, BOT_PASSWORD

BASE_URL = os.getenv("BASE_URL", "http://webapp:5000")

def setup_browser():
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    
    browser = webdriver.Chrome(options=chrome_options)
    return browser

def login(browser):
    browser.get(f"{BASE_URL}/login")
    
    username_field = browser.find_element(By.NAME, "username")
    password_field = browser.find_element(By.NAME, "password")
    
    username_field.send_keys(BOT_USERNAME)
    password_field.send_keys(BOT_PASSWORD)
    
    password_field.submit()
    
    WebDriverWait(browser, 10).until(
        EC.url_to_be(f"{BASE_URL}/dashboard")
    )
    
    print("Manager bot logged in successfully")

def ensure_logged_in(browser):
    if "/login" in browser.current_url:
        print("Session expired or logged out, re-logging in...")
        login(browser)

def check_for_requests(browser):
    browser.get(f"{BASE_URL}/requests")
    
    try:
        request_links = browser.find_elements(By.XPATH, "//a[contains(@href, '/requests/')]")
        if request_links:
            print(f"Found {len(request_links)} pending requests")
            return [link.get_attribute("href") for link in request_links]
        else:
            print("No pending requests found")
            return []
    except Exception as e:
        print(f"Error checking for requests: {e}")
        return []

def process_request(browser, request_url):
    print(f"Processing request at: {request_url}")
    browser.get(request_url)
    
    WebDriverWait(browser, 10).until(
        EC.presence_of_element_located((By.CLASS_NAME, "request-details"))
    )
    
    try:
        approve_button = browser.find_element(By.CSS_SELECTOR, "button.approve")
        approve_button.click()
        
        WebDriverWait(browser, 10).until(
            EC.url_to_be(f"{BASE_URL}/requests")
        )
        print("Request approved successfully")
        return True
    except Exception as e:
        print(f"Error approving request: {e}")
        return False

def bot_loop():
    browser = setup_browser()
    try:
        login(browser)
        
        while True:
            print("Checking for new requests...")
            browser.get(f"{BASE_URL}/dashboard")
            ensure_logged_in(browser)

            request_urls = check_for_requests(browser)
            
            for url in request_urls:
                browser.get(url)
                ensure_logged_in(browser)
                process_request(browser, url)
            
            time.sleep(30)
            
    except Exception as e:
        print(f"Bot error: {e}")
    finally:
        browser.quit()

if __name__ == "__main__":
    bot_loop()