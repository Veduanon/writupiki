import time
import uuid

users = {
    "manager": {
        "name": "Site",
        "surname": "Manager",
        "password": "m4n4g3r_s3cr3t_p4ssw0rd!Y&*G@&EG&Wgeru98279y7y3tWR",
        "role": "manager",
        "description": "System manager"
    }
}

requests = {}
reports = []
sessions = {}

class User:
    @staticmethod
    def get_user(username):
        return users.get(username)

    @staticmethod
    def add_user(username, name, surname, password, role, description=""):
        users[username] = {
            "name": name,
            "surname": surname,
            "password": password,
            "role": role,
            "description": description
        }
        return True

    @staticmethod
    def get_all_users():
        return users

class Request:
    @staticmethod
    def create_request(username, name, surname, password, description):
        request_id = str(uuid.uuid4())
        requests[request_id] = {
            "id": request_id,
            "username": username,
            "name": name,
            "surname": surname,
            "password": password,
            "description": description,
            "created_at": time.time()
        }
        return request_id

    @staticmethod
    def get_request(request_id):
        return requests.get(request_id)

    @staticmethod
    def get_all_requests():
        return requests
    
    @staticmethod
    def delete_request(request_id):
        if request_id in requests:
            del requests[request_id]
            return True
        return False

class Report:
    @staticmethod
    def create_report(title, description):
        report_id = str(uuid.uuid4())
        report = {
            "id": report_id,
            "title": title,
            "description": description,
            "created_at": time.time()
        }
        reports.append(report)
        return report

class Session:
    @staticmethod
    def create_session(username):
        session_id = str(uuid.uuid4())
        sessions[session_id] = {
            "username": username,
            "created_at": time.time()
        }
        return session_id

    @staticmethod
    def get_session(session_id):
        return sessions.get(session_id)

    @staticmethod
    def delete_session(session_id):
        if session_id in sessions:
            del sessions[session_id]
            return True
        return False