import os

BOT_USERNAME = "manager"
BOT_PASSWORD = "m4n4g3r_s3cr3t_p4ssw0rd!Y&*G@&EG&Wgeru98279y7y3tWR"

APP_NAME = "SecurePanel Admin System"